const UsuarioServicio = require('../servicios/usuario')
const SobremiServicio = require('../servicios/sobremi')
const SkillsServicio = require('../servicios/skills')

module.exports = {
    UsuarioServicio,
    SobremiServicio,
    SkillsServicio
}